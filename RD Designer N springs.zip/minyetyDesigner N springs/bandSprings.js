'use strict';
const bsInventory = [
 [42, '45 X 1,2'], 
 [51, '50 X 1,2'], 
 [59, '55 X 1,3'], 
 [42, '60 X 1,2'], 
 [42, '60 X 1,3'], 
 [42, '60 X 1,4'], 
 [42, '60 X 1,5']
 ];
 const rdWeight=255;
 /*
 rd weight
 test from smallest double highest bs capacity
 */
 
 function fetchLowrdt