'use strict';

const rd = {
  home: {
    nameOfComponent: '🤓 Welcome to RD Designer! 🤓',
    objectSketchFileName: 'rdclipart.jpg',
    noOfMeasurements: 0,
    namesOfMeasurements: ['',
      '',
      '',
      '',
      ''],
    previousComponent: 'welcomePage',
    nextComponent: 'wallCutout'
  },

  wallCutout: {
    nameOfComponent: 'Wall Cutout:',
    objectSketchFileName: 'wallCutout.jpg',
    noOfMeasurements: 5,
    namesOfMeasurements: ['Width',
      'Height',
      'Top Clearance',
      'Left Clearance',
      'Right Clearance'],
    previousComponent: 'welcomePage',
    nextComponent: 'barrel'
  },

  barrel: {
    nameOfComponent: 'Barrel:',
    objectSketchFileName: 'barrel.jpg',
    noOfMeasurements: 1,
    namesOfMeasurements: ['Rings Diameter'],
    previousComponent: 'barrel',
    nextComponent: 'slats'
  },

  slats: {
    nameOfComponent: 'Slats:',
    objectSketchFileName: 'slat.jpg',
    noOfMeasurements: 2,
    namesOfMeasurements: ['Gauge',
      'Width'],
    previousComponent: 'barrel',
    nextComponent: 'bottomBar'
  },

  bottomBar: {
    nameOfComponent: 'Bottom Bar:',
    objectSketchFileName: 'bottomBar.jpg',
    noOfMeasurements: 4,
    namesOfMeasurements: ['Angle Width',
      'Angle Height',
      'Angle Thickness',
      'Angles Qty.'],
    previousComponent: 'bottomBar',
    nextComponent: 'spring'
  },

  spring: {
    nameOfComponent: 'Torsion Spring:',
    objectSketchFileName: 'spring.jpg',
    noOfMeasurements: 1,
    namesOfMeasurements: ['Internal Diameter'],
    previousComponent: 'bottomBar',
    nextComponent: 'misc'
  },

  misc: {
    nameOfComponent: 'Miscellaneous Components:',
    objectSketchFileName: 'misc.jpg',
    noOfMeasurements: 5,
    namesOfMeasurements: ['Endlock Style',
      'Slide Bolt Style',
      'Astragal Style',
      'Windlock Style',
      'Slat Style'],
    previousComponent: 'spring',
    nextComponent: 'misc'
  }
};

let debugMessage;
const testSpan = document.querySelector('#test-span');

window.onload = function () {
  const pageId = document.querySelector('#page-id').getAttribute('class');
  console.log({
    pageId
  });
  if (pageId === 'template') {
    const componentNameNow = JSON.parse(window.localStorage.getItem('nextComponentName')); // What used to be nextComponentName for previous page is componentNameNow for current page.
    console.log ({
      componentNameNow
    });

    const heather = document.querySelector('#component-name-header');
    heather.innerHTML = eval(`rd.${componentNameNow}.nameOfComponent`);
    debugMessage = `pageId is: ${pageId}`;
    testSpan.innerHTML = debugMessage;
  } else {
    debugMessage = `pageId is: ${pageId}`;
    testSpan.innerHTML = debugMessage;

  }
};

const previousComponentBtn = document.querySelector ('#previous-component');

function previousComponentPage () {}
previousComponentBtn.addEventListener('click', previousComponentPage);

function stashNxtComponentName () {
  const nextComponentName = document.querySelector ('#next-component').getAttribute('placeholder');
  console.log ({
    nextComponentName
  });

  window.localStorage.setItem('nextComponentName', JSON.stringify(nextComponentName));
}

function switchToNxtComponent () {
  setTimeout(function() {
    window.location = 'main.html'
  }, 500);
}

const nextComponentBtn = document.querySelector ('#next-component');
nextComponentBtn.addEventListener('click', ()=> {
  stashNxtComponentName();
  switchToNxtComponent();
});