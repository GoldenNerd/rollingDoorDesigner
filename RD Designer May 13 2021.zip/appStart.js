'use strict';

// THE ROLLING DOOR OBJECT:
/*
The RD measurements template properties object.
*/
const rd = {
  startPage: {
    itemNo: 0,
    nameOfComponent: '🤓 Welcome to RD Designer! 🤓',
    componentSketchFileName: 'url(startPage.jpg)',
    noOfMeasurements: 0,
    labelsOfMeasurements: ['',
      '',
      '',
      '',
      ''],
    prevComObjName: 'startPage',
    activeObjectName: 'startPage',
    nextComponent: 'wallCutout'
  },

  wallCutout: {
    itemNo: 1,
    nameOfComponent: 'Wall Cutout:',
    componentSketchFileName: 'url(wallCutout.jpg)',
    noOfMeasurements: 5,
    labelsOfMeasurements: ['Width',
      'Height',
      'Top Clearance',
      'Left Clearance',
      'Right Clearance'],
      objKeysArray: ['width', 'height', 'topClearance', 'leftClearance', 'rightClearance'],
      activeObjMeasurements: {width: '', height: '', topClearance: '', leftClearance: '', rightClearance: ''},
    prevComObjName: 'startPage',
    activeObjectName: 'wallCutout',
    nextComponent: 'barrel'
  },

  barrel: {
    itemNo: 2,
    nameOfComponent: 'Barrel:',
    componentSketchFileName: 'url(barrel.jpg)',
    noOfMeasurements: 1,
    labelsOfMeasurements: ['Rings Diameter', '', '', '', ''],
    capturedMeasurements: [],
    prevComObjName: 'wallCutout',
    activeObjectName: 'barrel',
    nextComponent: 'slats'
  },

  slats: {
    itemNo: 3,
    nameOfComponent: 'Slats:',
    componentSketchFileName: 'url(slats.jpg)',
    noOfMeasurements: 2,
    labelsOfMeasurements: ['Gauge',
      'Width', '', '', ''],
    capturedMeasurements: [],
    prevComObjName: 'barrel',
    activeObjectName: 'slats',
    nextComponent: 'bottomBar'
  },

  bottomBar: {
    itemNo: 4,
    nameOfComponent: 'Bottom Bar:',
    componentSketchFileName: 'url(bottomBar.jpg)',
    noOfMeasurements: 4,
    labelsOfMeasurements: ['Angle Width',
      'Angle Height',
      'Angle Thickness',
      'Angles Qty.', ''],
    capturedMeasurements: [],
    prevComObjName: 'slats',
    activeObjectName: 'bottomBar',
    nextComponent: 'spring'
  },

  spring: {
    itemNo: 5,
    nameOfComponent: 'Torsion Spring:',
    componentSketchFileName: 'url(spring.jpg)',
    noOfMeasurements: 1,
    labelsOfMeasurements: ['Internal Diameter', '', '', '', ''],
    capturedMeasurements: [],
    prevComObjName: 'bottomBar',
    activeObjectName: 'spring',
    nextComponent: 'misc'
  },

  misc: {
    itemNo: 6,
    nameOfComponent: 'Miscellaneous Components:',
    componentSketchFileName: 'url(misc.jpg)',
    noOfMeasurements: 5,
    labelsOfMeasurements: ['Endlock Style',
      'Slide Bolt Style',
      'Astragal Style',
      'Windlock Style',
      'Slat Style'],
    capturedMeasurements: [],
    prevComObjName: 'spring',
    activeObjectName: 'misc',
    nextComponent: 'misc'
  }
};

/*
Note: The Template ID is hard coded in the page. Therefore it is a primary reference entry point.
*/
function returnTemplateId () {
  const templateIdAttr = document.querySelector('#template-id').getAttribute('class');
  return templateIdAttr;
  
}

// Initialize LocSt w/ home Page's Name
/*
Save the activeObjectName of the home page to localStorage. This is necessarily for consistency. Because then I can use the same navigation rules, etc. for all pages.
*/
function homePageNameToLocSto () {
  window.localStorage.clear();
  const homePageName = 'startPage';
  window.localStorage.setItem('nxtCompNamePassedOnByPrevCompPage', JSON.stringify(homePageName));
}

/*
Retrieve from localStorage the component obj name that will be used to build the page:
*/
function activeCompObjNameFromLS () {
  const compObjNameNow = JSON.parse(window.localStorage.getItem('nxtCompNamePassedOnByPrevCompPage'));
  /* The reference frame for the naming convention (previous, now, next) is the page currently on display. What used to be nextComponentName for previous page is compObjNameNow for current page, and so on.
    */
  return compObjNameNow;
}

function displayTemplateId () {
  const templateId = document.querySelector('#template-id');
  const templateIdAttr = document.querySelector('#template-id').getAttribute('class');
  templateId.innerHTML = `templateId is: ${templateIdAttr}`;
}

/*
Establish the component's object name of the page. In other words, embed the activeCompObjName into a span placeholder attribute in the DOM. This attribute will be used to build a pointer to the active component object that holds all active page properties. In turn, these properties will be use to build pages on the fly using a common document template. AGENIUS!!:
*/
function establishPageName () {
  const compObjNameNow = activeCompObjNameFromLS();
  const nameOfComponentObj = document.querySelector('#name-of-component-obj');
  nameOfComponentObj.setAttribute('class', `${compObjNameNow}`);
}

/*
Note: The term [document.querySelector('#name-of-component-obj').getAttribute('class')] is the active component object.
*/
function returnTheActiveCompObj () {
  const activeObject = rd[document.querySelector('#name-of-component-obj').getAttribute('class')];
  return activeObject;
}

function returnTheActivePageName () {
  const nameOfActivePage = returnTheActiveCompObj().activeObjectName;
  return `${nameOfActivePage}`;
}

function displayPageName () {
  const pageName = document.querySelector('#name-of-component-obj');
  pageName.innerHTML = `pageName is: ${returnTheActivePageName()}`;
}

/*
Populate the page's top heather:
*/
function populatePageTopHeather () {
  const topHeather = document.querySelector('#component-name-header');
  topHeather.innerHTML = returnTheActiveCompObj().nameOfComponent;
}

//Display component sketch:
function PopulateCompSketchFrame () {
  const pointerToSketchName = returnTheActiveCompObj().componentSketchFileName;
  document.querySelector(':root').style.setProperty('--component-sketch', `${pointerToSketchName}`);
  }

/*
Back button label must show Start Page if first component page is on display 
*/
function updatePrevBtnLabel () {
if (returnTheActiveCompObj().itemNo===1) {
  previousComponentBtn.value='Start Page';
}
}

/*
On page load, populate all page labels according to its component obj name.
*/
function populateDatumLabels () {
const datumLabelsPlaceholders=document.getElementsByClassName('datum-labels');
const datumLabels=returnTheActiveCompObj().labelsOfMeasurements;
for(let i=0; i<datumLabelsPlaceholders.length; i++){
 datumLabelsPlaceholders[i].innerHTML =datumLabels[i];
}
}

function hideEmptyDatums () {
const measurementsList=Array.from (document.getElementsByTagName('li')) ;
const labelsOfMeasurements=returnTheActiveCompObj().labelsOfMeasurements;

for(let i=0; i<labelsOfMeasurements.length;i++){

if (labelsOfMeasurements[i]==='') {
measurementsList[i].style.position=('absolute');
measurementsList[i].style.top=('-400%');
}
}
}

window.onload = function () {
  // Read Template ID of the Page and simultaneously populate template id label:
  const templateId = returnTemplateId();
  // Chk if home template
  if (templateId === 'home') {
    // Initialize LocSt w/ home's Page Name:
    homePageNameToLocSto();
  }
  // Now handle home page as any other component page...
  // Populate template ID label (debbugging only. Not needed):
 // displayTemplateId();
  // Determine Page Name:
  establishPageName();
  // Populate page name label (debbugging only. Not needed):
 // displayPageName();
  //displayAndReturnPageName();
  //populate page top heather:
  populatePageTopHeather();
  //Display component sketch:
  PopulateCompSketchFrame();
  
  updatePrevBtnLabel();
  
  // datum-labels
  populateDatumLabels();
  
hideEmptyDatums();
};

// BELOW IS THE NAVIGATION OF THE APP:
function stashNxtComponentName () {
  const nextComponentName =returnTheActiveCompObj().nextComponent;
  window.localStorage.setItem('nxtCompNamePassedOnByPrevCompPage', JSON.stringify(nextComponentName));
}
/*
Switch to the next component page after a brief time delay. Delay allows time for current page to save next page name to localStorage before transferring control to next page.
*/

function switchToNxtComponent () {
  setTimeout(function() {
    window.location = 'mainTemplate.html';}, 10);

}

/*
Actions of the Previous Component navigation button:
*/
function stashPrevComponentName () {
  const prevComponentName =returnTheActiveCompObj().prevComObjName;
  window.localStorage.setItem('nxtCompNamePassedOnByPrevCompPage', JSON.stringify(prevComponentName));
}
/*
Switch to the previous component page after a brief time delay. Delay allows time for current page to save previous page name to localStorage before transferring control to previous page.
*/

/*
function switchToHomeTemplate () {
if (returnTheActiveCompObj().itemNo===0) {
  window.location='home.html';
}
}
*/

function switchToPrevComponent () {
  setTimeout(function() {
/*
Going back from the first component page must load the start page. 
*/
    if (returnTheActiveCompObj().itemNo===1) {
window.location='home.html';
}else{
window.location = 'mainTemplate.html';}
}, 100);

}

const previousComponentBtn = document.querySelector ('#previous-page');
function previousComponentPage () {}
previousComponentBtn.addEventListener('click', ()=> {
  stashPrevComponentName(); // LocalStorage previous component page relative to the current component page.
  switchToPrevComponent(); // Switch to the previous component page after a brief time delay.
});
/*
Actions of the Next Component navigation button:
*/
const nextComponentBtn = document.querySelector ('#next-page');
nextComponentBtn.addEventListener('click', ()=> {
  stashNxtComponentName(); // LocalStorage next component page relative to the current component page.
  switchToNxtComponent(); // Switch to the next component page after a brief time delay.
});


// BELOW IS THE DATA CAPTURE OF THE APP:

let inchesTyped_a;
let inchesTyped_b;
let inchesTyped_c;
let inchesTyped_d;
let inchesTyped_e;

const inchedTypedArray=[inchesTyped_a, inchesTyped_b, inchesTyped_c, inchesTyped_d, inchesTyped_e];

let a;
let b;
let c;
let d;
let e;

const wallCutout={
  width: a,
  height: b,
  topClearance: c,
  leftClearance: d,
  rightClearance: e
};

function activeCompObjMeasutements () {
// Collect inches data
const inchedTypedCollection=document.querySelectorAll('.inches-value');
// Collect feet inchesData
const feetTypedCollection=document.querySelectorAll('.feet-value');
const dataConvertedToInches =[];
  // simultaneously loading of feetData, conversion of feet to inched, and adding inches data for each measurement. 
for (let i = 0; i < feetTypedCollection.length; i++) {
  dataConvertedToInches[i] = 12*feetTypedCollection[i].value + 1*inchedTypedCollection[i].value;
} 
console.log ('Captured Data in inches: ', {dataConvertedToInches});

// Building object of measurements
const activeObj=returnTheActiveCompObj();
const arrayOfKeys=returnTheActiveCompObj().objKeysArray;
const measurementsContainerObj=returnTheActiveCompObj().activeObjMeasurements;
const length=returnTheActiveCompObj().noOfMeasurements;
for (let i = 0; i < length; i++) {
  console.log (returnTheActiveCompObj());
  returnTheActiveCompObj().activeObjMeasurements.returnTheActiveCompObj()[`objKeysArray${[i]}`] =dataConvertedToInches[i];
}
return measurementsContainerObj;
} 

function captureComponentMeasurements () {
  console.log(activeCompObjMeasutements());
}


const getMeasurementsBtn=document.querySelector('#load-measurements');
getMeasurementsBtn.addEventListener('click', captureComponentMeasurements);



