

`${objKeys[i]}`=dataConvertedToInches[i]
{ {objKey: keyValue}, {} };
const activeCompObjMeasurements=returnTheActiveCompObj().activeCompObjMeasurements;
for(let i=0; i<u.length;i++) {
Object.keys(activeCompObjMeasurements[i])[0]=dataConvertedToInches[i];
}

activeCompObj.activeObjMeasurements [{width: a},...]

 wallCutout.width=dataConvertedToInches[0];
  wallCutout.height= dataConvertedToInches[1];
  wallCutout.topClearance=dataConvertedToInches[2];
  wallCutout.leftClearance=dataConvertedToInches[3];
  wallCutout.rightClearance=dataConvertedToInches[4];
 